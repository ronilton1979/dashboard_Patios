-- ========================================
-- DASHBOARD ERROS PÁTIOS - BANCO DE DADOS
-- ========================================

-- Criar banco de dados
CREATE DATABASE IF NOT EXISTS dashboard_erros;
USE dashboard_erros;

-- Tabela de Erros
CREATE TABLE IF NOT EXISTS erros (
  id INT AUTO_INCREMENT PRIMARY KEY,
  data DATE NOT NULL,
  colaborador VARCHAR(100) NOT NULL,
  patios VARCHAR(50) NOT NULL,
  obs TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_data (data),
  INDEX idx_colaborador (colaborador),
  INDEX idx_patios (patios),
  FULLTEXT INDEX ft_obs (obs)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de Resumo (Cache para melhor performance)
CREATE TABLE IF NOT EXISTS resumo_erros (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tipo ENUM('patio', 'colaborador', 'obs') NOT NULL,
  nome VARCHAR(255) NOT NULL,
  quantidade INT NOT NULL,
  data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY unique_resumo (tipo, nome),
  INDEX idx_tipo (tipo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de Filtros (para armazenar filtros salvos)
CREATE TABLE IF NOT EXISTS filtros_salvos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome_filtro VARCHAR(100) NOT NULL,
  data_inicio DATE,
  data_fim DATE,
  patios TEXT,
  colaboradores TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Criar índices para melhor performance
CREATE INDEX idx_data_patio ON erros(data, patios);
CREATE INDEX idx_data_colaborador ON erros(data, colaborador);
CREATE INDEX idx_patio_colaborador ON erros(patios, colaborador);

-- Criar view para top 5 pátios
CREATE OR REPLACE VIEW top_5_patios AS
SELECT patios, COUNT(*) as quantidade
FROM erros
GROUP BY patios
ORDER BY quantidade DESC
LIMIT 5;

-- Criar view para top 5 colaboradores
CREATE OR REPLACE VIEW top_5_colaboradores AS
SELECT colaborador, COUNT(*) as quantidade
FROM erros
GROUP BY colaborador
ORDER BY quantidade DESC
LIMIT 5;

-- Criar view para top 5 erros (OBS)
CREATE OR REPLACE VIEW top_5_obs AS
SELECT obs, COUNT(*) as quantidade
FROM erros
GROUP BY obs
ORDER BY quantidade DESC
LIMIT 5;
