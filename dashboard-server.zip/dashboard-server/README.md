# Dashboard Erros Pátios - Servidor Independente

Dashboard profissional para análise de erros por pátio, colaborador e tipo de erro. Totalmente responsivo com design Cyberpunk Neon.

## 📋 Requisitos

- **Node.js** >= 18.0.0
- **MySQL** >= 8.0 ou **MariaDB** >= 10.5
- **Docker** e **Docker Compose** (opcional, para containerização)
- **npm** >= 9.0.0

## 🚀 Instalação Rápida (Docker)

### 1. Clone o repositório
```bash
git clone <seu-repositorio>
cd dashboard-server
```

### 2. Configure as variáveis de ambiente
```bash
cp .env.example .env
# Edite .env com suas configurações
```

### 3. Inicie os containers
```bash
docker-compose up -d
```

### 4. Acesse o dashboard
- **Frontend**: http://localhost
- **API**: http://localhost/api
- **Health Check**: http://localhost/api/health

## 🔧 Instalação Manual

### 1. Instale as dependências
```bash
npm install
```

### 2. Configure o banco de dados

#### Opção A: MySQL local
```bash
# Criar banco de dados
mysql -u root -p < database.sql

# Importar dados
mysql -u root -p dashboard_erros < seed.sql
```

#### Opção B: Importar CSV completo
```bash
mysql -u root -p dashboard_erros -e "LOAD DATA LOCAL INFILE '/path/to/dashboard_clean.csv' INTO TABLE erros FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' IGNORE 1 ROWS (data, colaborador, patios, obs);"
```

### 3. Configure as variáveis de ambiente
```bash
cp .env.example .env
# Edite .env com suas credenciais do MySQL
```

### 4. Inicie o servidor
```bash
# Desenvolvimento
npm run dev

# Produção
npm start
```

O servidor estará disponível em `http://localhost:3001`

## 📊 Estrutura do Banco de Dados

### Tabela: `erros`
- `id` (INT, PK, AUTO_INCREMENT)
- `data` (DATE)
- `colaborador` (VARCHAR)
- `patios` (VARCHAR)
- `obs` (TEXT)
- `created_at` (TIMESTAMP)

### Índices
- `idx_data` - Para filtros por data
- `idx_colaborador` - Para filtros por colaborador
- `idx_patios` - Para filtros por pátio
- `ft_obs` - Full-text search em observações

### Views
- `top_5_patios` - Top 5 pátios com mais erros
- `top_5_colaboradores` - Top 5 colaboradores com mais erros
- `top_5_obs` - Top 5 tipos de erro mais comuns

## 🔌 Endpoints da API

### Erros
- `GET /api/erros` - Listar erros com filtros
- `GET /api/erros?data_inicio=2026-02-02&data_fim=2026-02-26`
- `GET /api/erros?patio=PATIO%203`
- `GET /api/erros?colaborador=GABRIEL%20ANDRADE`
- `GET /api/erros?page=1&limit=50`

### Estatísticas
- `GET /api/top-patios` - Top 5 pátios
- `GET /api/top-colaboradores` - Top 5 colaboradores
- `GET /api/top-obs` - Top 5 observações (tipos de erro)
- `GET /api/stats` - Estatísticas gerais

### Filtros
- `GET /api/patios` - Lista de pátios únicos
- `GET /api/colaboradores` - Lista de colaboradores únicos
- `GET /api/date-range` - Intervalo de datas disponível

### Health
- `GET /api/health` - Status do servidor

## 🐳 Docker Compose

### Serviços inclusos
1. **MySQL** - Banco de dados
2. **Node.js API** - Servidor backend
3. **Nginx** - Proxy reverso (opcional)

### Comandos úteis
```bash
# Iniciar
docker-compose up -d

# Parar
docker-compose down

# Ver logs
docker-compose logs -f api

# Reiniciar
docker-compose restart

# Reconstruir
docker-compose up -d --build
```

## 🔐 Segurança

### Configurações de Segurança Incluídas
- CORS habilitado (configure conforme necessário)
- Rate limiting no Nginx
- Headers de segurança (HSTS, X-Frame-Options, etc.)
- SSL/TLS (configure certificados)
- SQL Injection prevention (prepared statements)

### Certificados SSL
Para gerar certificados com Let's Encrypt:
```bash
# Instale certbot
sudo apt-get install certbot python3-certbot-nginx

# Gere certificados
sudo certbot certonly --standalone -d seu-dominio.com

# Copie para o diretório ssl/
sudo cp /etc/letsencrypt/live/seu-dominio.com/fullchain.pem ./ssl/cert.pem
sudo cp /etc/letsencrypt/live/seu-dominio.com/privkey.pem ./ssl/key.pem
```

## 📈 Performance

### Otimizações Implementadas
- Connection pooling (MySQL)
- Gzip compression (Nginx)
- Caching de arquivos estáticos
- Índices de banco de dados
- Rate limiting

### Monitoramento
```bash
# Ver uso de recursos
docker stats

# Ver logs
docker-compose logs -f

# Health check
curl http://localhost:3001/api/health
```

## 🚢 Deploy em Produção

### Opção 1: Heroku
```bash
git push heroku main
```

### Opção 2: AWS EC2
```bash
# SSH na instância
ssh -i seu-key.pem ubuntu@seu-ip

# Clone o repositório
git clone <seu-repositorio>
cd dashboard-server

# Inicie com Docker Compose
docker-compose up -d
```

### Opção 3: DigitalOcean
```bash
# Crie um App Platform
# Conecte seu repositório GitHub
# Configure variáveis de ambiente
# Deploy automático
```

### Opção 4: Servidor Próprio
```bash
# Instale Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Instale MySQL
sudo apt-get install -y mysql-server

# Configure o banco de dados
sudo mysql < database.sql

# Instale PM2 para gerenciar processo
sudo npm install -g pm2
pm2 start server.js --name "dashboard"
pm2 startup
pm2 save
```

## 📝 Variáveis de Ambiente

```env
# Banco de Dados
DB_HOST=localhost
DB_PORT=3306
DB_USER=dashboard
DB_PASSWORD=sua_senha
DB_NAME=dashboard_erros

# Servidor
PORT=3001
NODE_ENV=production

# CORS
CORS_ORIGIN=*

# Segurança
JWT_SECRET=sua_chave_secreta
API_KEY=sua_api_key

# Logs
LOG_LEVEL=info
```

## 🐛 Troubleshooting

### Erro: "Connection refused"
```bash
# Verifique se MySQL está rodando
docker-compose ps

# Reinicie os serviços
docker-compose restart
```

### Erro: "Cannot find module"
```bash
# Reinstale dependências
npm install
```

### Erro: "Port already in use"
```bash
# Mude a porta em .env
PORT=3002
```

## 📞 Suporte

Para problemas ou dúvidas:
1. Verifique os logs: `docker-compose logs -f`
2. Teste a API: `curl http://localhost:3001/api/health`
3. Verifique o banco de dados: `docker-compose exec mysql mysql -u root -p`

## 📄 Licença

MIT License - veja LICENSE.md para detalhes

## 🎉 Créditos

Dashboard desenvolvido com React, Express.js, MySQL e Nginx.
Design: Cyberpunk Neon com cores vibrantes.
