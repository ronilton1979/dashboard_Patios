# ⚡ Quick Start - Dashboard Erros Pátios

## 🎯 Início Rápido (5 minutos)

### Opção 1: Docker (Recomendado)
```bash
# 1. Extraia o arquivo
tar -xzf dashboard-server.tar.gz
cd dashboard-server

# 2. Configure
cp .env.example .env

# 3. Inicie
docker-compose up -d

# 4. Acesse
# Frontend: http://localhost
# API: http://localhost/api
```

### Opção 2: Node.js Local
```bash
# 1. Extraia
tar -xzf dashboard-server.tar.gz
cd dashboard-server

# 2. Instale
npm install

# 3. Configure
cp .env.example .env
# Edite .env com suas credenciais MySQL

# 4. Setup do banco
mysql -u root -p < database.sql

# 5. Inicie
npm start

# 6. Acesse
# http://localhost:3001
```

## 📋 Arquivos Inclusos

| Arquivo | Descrição |
|---------|-----------|
| `server.js` | API Express.js com 8 endpoints |
| `database.sql` | Schema MySQL completo |
| `seed.sql` | Dados iniciais |
| `public/index.html` | Frontend HTML/CSS/JS |
| `Dockerfile` | Containerização |
| `docker-compose.yml` | Orquestração |
| `nginx.conf` | Proxy reverso |
| `package.json` | Dependências |
| `.env.example` | Variáveis de ambiente |

## 🔌 Endpoints da API

```bash
# Listar erros
curl http://localhost:3001/api/erros

# Top 5 pátios
curl http://localhost:3001/api/top-patios

# Top 5 colaboradores
curl http://localhost:3001/api/top-colaboradores

# Top 5 observações
curl http://localhost:3001/api/top-obs

# Estatísticas
curl http://localhost:3001/api/stats

# Health check
curl http://localhost:3001/api/health
```

## 🗄️ Banco de Dados

### Credenciais Padrão
- **Host**: localhost
- **User**: root
- **Password**: (vazia ou configure em .env)
- **Database**: dashboard_erros

### Importar dados completos (357 registros)
```bash
mysql -u root -p dashboard_erros < seed.sql
```

## 🚀 Deploy Rápido

### Heroku
```bash
heroku create seu-app
heroku config:set DB_HOST=seu-host
git push heroku main
```

### Railway
```bash
railway login
railway init
railway up
```

### DigitalOcean
1. Acesse App Platform
2. Conecte GitHub
3. Configure variáveis
4. Deploy

## 📊 Dados

- **Total**: 357 erros
- **Período**: 02/02/2026 a 26/02/2026
- **Pátios**: 11 únicos
- **Colaboradores**: 50 únicos
- **Tipos de erro**: 23 únicos

## 🎨 Design

- **Tema**: Cyberpunk Neon
- **Cores**: Cyan, Magenta, Verde
- **Responsivo**: Mobile + Desktop
- **Sem dependências externas**: Apenas Tailwind CSS

## 🔧 Troubleshooting

### Erro: "Cannot connect to database"
```bash
# Verifique MySQL
mysql -u root -p -e "SELECT 1"

# Verifique .env
cat .env
```

### Erro: "Port already in use"
```bash
# Mude a porta em .env
PORT=3002
```

### Erro: "Docker not found"
```bash
# Instale Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
```

## 📚 Documentação Completa

- `README.md` - Documentação completa
- `DEPLOY.md` - 7 opções de deploy
- `ESTRUTURA.md` - Estrutura do projeto

## 🆘 Suporte

1. Verifique os logs: `docker-compose logs -f`
2. Teste a API: `curl http://localhost:3001/api/health`
3. Consulte a documentação

## ✅ Checklist de Instalação

- [ ] Extrair arquivo
- [ ] Configurar .env
- [ ] Instalar dependências (npm install)
- [ ] Setup do banco (mysql < database.sql)
- [ ] Iniciar servidor (npm start ou docker-compose up)
- [ ] Acessar http://localhost:3001
- [ ] Testar API (curl http://localhost:3001/api/health)

## 🎉 Pronto!

Seu dashboard está rodando! 🚀

Acesse: **http://localhost:3001**
