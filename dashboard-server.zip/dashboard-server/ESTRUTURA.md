# 📁 Estrutura do Projeto

```
dashboard-server/
│
├── 📄 server.js                    # Servidor Node.js/Express (API Backend)
├── 📄 database.sql                 # Schema do banco de dados MySQL
├── 📄 seed.sql                     # Dados iniciais para o banco
├── 📄 package.json                 # Dependências do projeto
│
├── 🐳 Dockerfile                   # Configuração Docker
├── 🐳 docker-compose.yml           # Orquestração de containers
├── 🌐 nginx.conf                   # Configuração do servidor Nginx
│
├── 📋 README.md                    # Documentação principal
├── 🚀 DEPLOY.md                    # Guia de deployment
├── 📁 ESTRUTURA.md                 # Este arquivo
│
├── 🔐 .env.example                 # Variáveis de ambiente (template)
├── .gitignore                      # Arquivos ignorados pelo Git
│
└── 📂 public/                      # Arquivos estáticos (frontend)
    └── 📄 index.html               # Frontend HTML/CSS/JS
```

## 📊 Arquivos Principais

### Backend

#### `server.js` (API Express.js)
- Servidor Node.js com Express
- 8 endpoints REST
- Conexão com MySQL
- CORS habilitado
- Health checks

**Endpoints:**
- `GET /api/erros` - Listar erros com filtros
- `GET /api/top-patios` - Top 5 pátios
- `GET /api/top-colaboradores` - Top 5 colaboradores
- `GET /api/top-obs` - Top 5 observações
- `GET /api/stats` - Estatísticas gerais
- `GET /api/patios` - Lista de pátios
- `GET /api/colaboradores` - Lista de colaboradores
- `GET /api/date-range` - Intervalo de datas
- `GET /api/health` - Health check

### Banco de Dados

#### `database.sql`
- Schema completo do MySQL
- 3 tabelas principais
- Índices otimizados
- 3 views para relatórios
- Full-text search em observações

**Tabelas:**
- `erros` - Registros de erros (357 linhas)
- `resumo_erros` - Cache de resumos
- `filtros_salvos` - Filtros salvos pelos usuários

#### `seed.sql`
- Dados iniciais para testes
- Importação de CSV
- Atualização de cache

### Frontend

#### `public/index.html`
- HTML5 + CSS3 + JavaScript vanilla
- Design Cyberpunk Neon
- Responsivo (mobile + desktop)
- Sem dependências externas (exceto Tailwind)
- Gráficos em tempo real

**Componentes:**
- Header com título e timestamp
- Filtros interativos (data, pátio, colaborador)
- Estatísticas (cards)
- Gráficos (barras e pizza)
- Footer

### Configuração

#### `package.json`
```json
{
  "name": "dashboard-erros-patios",
  "version": "1.0.0",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js",
    "db:setup": "mysql -u root -p < database.sql",
    "db:seed": "mysql -u root -p < seed.sql"
  },
  "dependencies": {
    "express": "^4.21.2",
    "mysql2": "^3.6.5",
    "cors": "^2.8.5",
    "dotenv": "^16.3.1"
  }
}
```

#### `.env.example`
```env
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=sua_senha
DB_NAME=dashboard_erros
PORT=3001
NODE_ENV=production
```

### Docker

#### `Dockerfile`
- Build multi-stage
- Node.js 18 Alpine
- Otimizado para produção
- Health checks integrados

#### `docker-compose.yml`
- 3 serviços: MySQL, Node.js API, Nginx
- Volumes persistentes
- Network isolada
- Restart automático

#### `nginx.conf`
- Proxy reverso
- SSL/TLS
- Rate limiting
- Gzip compression
- Cache de arquivos estáticos
- Headers de segurança

### Documentação

#### `README.md`
- Instruções de instalação
- Guia de uso
- Endpoints da API
- Troubleshooting

#### `DEPLOY.md`
- 7 opções de deploy
- Passo a passo para cada uma
- Configuração de segurança
- Monitoramento
- CI/CD

## 🔄 Fluxo de Dados

```
┌─────────────────┐
│   Frontend      │ (HTML/CSS/JS - public/index.html)
│  (Navegador)    │
└────────┬────────┘
         │ HTTP/REST
         ▼
┌─────────────────┐
│  Nginx Proxy    │ (nginx.conf)
│  (Reverse Proxy)│
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Express API    │ (server.js)
│  (Node.js)      │
└────────┬────────┘
         │ SQL
         ▼
┌─────────────────┐
│  MySQL Database │ (database.sql)
│  (Dados)        │
└─────────────────┘
```

## 📦 Dependências

### Produção
- **express** - Framework web
- **mysql2** - Driver MySQL
- **cors** - Middleware CORS
- **dotenv** - Variáveis de ambiente

### Desenvolvimento
- **nodemon** - Auto-reload

### Frontend
- **Tailwind CSS** - Framework CSS
- **Recharts** - Biblioteca de gráficos (opcional)

## 🚀 Como Usar

### 1. Instalação Local
```bash
npm install
cp .env.example .env
# Edite .env com suas credenciais MySQL
mysql -u root -p < database.sql
npm start
```

### 2. Docker
```bash
docker-compose up -d
# Acesse http://localhost
```

### 3. Deploy
Veja `DEPLOY.md` para 7 opções diferentes

## 📊 Dados

### Importação CSV
```bash
mysql -u root -p dashboard_erros -e "LOAD DATA LOCAL INFILE '/path/to/dashboard_clean.csv' INTO TABLE erros FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' IGNORE 1 ROWS (data, colaborador, patios, obs);"
```

### Estatísticas
- **Total de Registros**: 357
- **Período**: 02/02/2026 a 26/02/2026
- **Pátios Únicos**: 11
- **Colaboradores**: 50
- **Tipos de Erro**: 23

## 🔐 Segurança

- SQL Injection Prevention (Prepared Statements)
- CORS Habilitado
- Rate Limiting (Nginx)
- SSL/TLS Support
- Headers de Segurança
- Environment Variables

## 🎨 Design

- **Tema**: Cyberpunk Neon
- **Cores**: Cyan (#00ffff), Magenta (#ff00ff), Verde (#00ff00)
- **Tipografia**: Space Mono, Orbitron
- **Responsividade**: Mobile-first
- **Animações**: Smooth transitions

## 📈 Performance

- Connection Pooling (MySQL)
- Gzip Compression
- Caching de Arquivos Estáticos
- Índices de Banco de Dados
- Rate Limiting
- Health Checks

## 🧪 Testes

```bash
# Health Check
curl http://localhost:3001/api/health

# Listar Erros
curl http://localhost:3001/api/erros

# Top Pátios
curl http://localhost:3001/api/top-patios

# Top Colaboradores
curl http://localhost:3001/api/top-colaboradores

# Top Observações
curl http://localhost:3001/api/top-obs

# Estatísticas
curl http://localhost:3001/api/stats
```

## 📞 Suporte

Para dúvidas ou problemas:
1. Verifique os logs: `docker-compose logs -f`
2. Teste a API: `curl http://localhost:3001/api/health`
3. Consulte `README.md` e `DEPLOY.md`
