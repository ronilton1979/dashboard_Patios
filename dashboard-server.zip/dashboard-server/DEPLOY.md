# 🚀 Guia de Deploy - Dashboard Erros Pátios

## Opções de Deploy

### 1️⃣ Docker Compose (Recomendado)

#### Pré-requisitos
- Docker >= 20.10
- Docker Compose >= 1.29

#### Passos
```bash
# Clone o repositório
git clone <seu-repositorio>
cd dashboard-server

# Configure o arquivo .env
cp .env.example .env
# Edite .env com suas credenciais

# Inicie os containers
docker-compose up -d

# Verifique o status
docker-compose ps

# Acesse
# Frontend: http://localhost
# API: http://localhost/api
```

---

### 2️⃣ Heroku

#### Pré-requisitos
- Conta Heroku
- Heroku CLI instalado

#### Passos
```bash
# Faça login no Heroku
heroku login

# Crie uma nova app
heroku create seu-app-name

# Configure as variáveis de ambiente
heroku config:set DB_HOST=seu-mysql-host
heroku config:set DB_USER=seu-usuario
heroku config:set DB_PASSWORD=sua-senha
heroku config:set DB_NAME=dashboard_erros

# Deploy
git push heroku main

# Verifique os logs
heroku logs --tail
```

---

### 3️⃣ AWS EC2

#### Pré-requisitos
- Conta AWS
- EC2 instance (Ubuntu 22.04)
- Security group com portas 80, 443, 3001 abertas

#### Passos
```bash
# SSH na instância
ssh -i seu-key.pem ubuntu@seu-ip

# Atualize o sistema
sudo apt update && sudo apt upgrade -y

# Instale Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Instale Docker
sudo apt install -y docker.io docker-compose

# Clone o repositório
git clone <seu-repositorio>
cd dashboard-server

# Configure .env
cp .env.example .env
nano .env  # Edite as configurações

# Inicie com Docker Compose
sudo docker-compose up -d

# Configure Nginx como proxy reverso
sudo apt install -y nginx
# Copie sua configuração nginx.conf para /etc/nginx/nginx.conf
sudo systemctl restart nginx
```

---

### 4️⃣ DigitalOcean

#### Opção A: App Platform (Recomendado)
1. Acesse DigitalOcean Dashboard
2. Clique em "Create" → "App"
3. Conecte seu repositório GitHub
4. Configure as variáveis de ambiente
5. Deploy automático

#### Opção B: Droplet
```bash
# SSH no droplet
ssh root@seu-ip

# Siga os mesmos passos do AWS EC2
```

---

### 5️⃣ Railway

#### Pré-requisitos
- Conta Railway
- Railway CLI

#### Passos
```bash
# Faça login
railway login

# Inicie um novo projeto
railway init

# Configure as variáveis
railway variables set DB_HOST=seu-host
railway variables set DB_USER=seu-usuario
railway variables set DB_PASSWORD=sua-senha

# Deploy
railway up
```

---

### 6️⃣ Render

#### Pré-requisitos
- Conta Render
- Repositório GitHub

#### Passos
1. Acesse https://dashboard.render.com
2. Clique em "New +" → "Web Service"
3. Conecte seu repositório GitHub
4. Configure:
   - Build Command: `npm install`
   - Start Command: `npm start`
5. Configure variáveis de ambiente
6. Deploy

---

### 7️⃣ Servidor Próprio (VPS/Dedicado)

#### Pré-requisitos
- Servidor Linux (Ubuntu 22.04 recomendado)
- Acesso SSH
- Domínio (opcional)

#### Instalação Completa
```bash
# 1. Conecte ao servidor
ssh root@seu-ip

# 2. Atualize o sistema
apt update && apt upgrade -y

# 3. Instale Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
apt install -y nodejs npm

# 4. Instale MySQL
apt install -y mysql-server

# 5. Instale Nginx
apt install -y nginx

# 6. Instale PM2 (gerenciador de processos)
npm install -g pm2

# 7. Clone o repositório
cd /var/www
git clone <seu-repositorio>
cd dashboard-server

# 8. Instale dependências
npm install

# 9. Configure o banco de dados
mysql -u root -p < database.sql
mysql -u root -p dashboard_erros < seed.sql

# 10. Configure .env
cp .env.example .env
nano .env  # Edite as configurações

# 11. Inicie com PM2
pm2 start server.js --name "dashboard"
pm2 startup
pm2 save

# 12. Configure Nginx como proxy reverso
# Edite /etc/nginx/sites-available/default
# Adicione:
# server {
#     listen 80;
#     server_name seu-dominio.com;
#     location / {
#         proxy_pass http://localhost:3001;
#     }
# }

systemctl restart nginx

# 13. Configure SSL com Let's Encrypt
apt install -y certbot python3-certbot-nginx
certbot --nginx -d seu-dominio.com

# 14. Verifique o status
pm2 status
```

---

## 🔒 Configuração de Segurança

### Certificados SSL
```bash
# Let's Encrypt (Gratuito)
certbot certonly --standalone -d seu-dominio.com

# Copie para o projeto
cp /etc/letsencrypt/live/seu-dominio.com/fullchain.pem ./ssl/cert.pem
cp /etc/letsencrypt/live/seu-dominio.com/privkey.pem ./ssl/key.pem

# Auto-renovação
certbot renew --dry-run
```

### Firewall
```bash
# UFW (Ubuntu)
ufw enable
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow 3001/tcp
```

### Backup do Banco de Dados
```bash
# Backup manual
mysqldump -u root -p dashboard_erros > backup.sql

# Restore
mysql -u root -p dashboard_erros < backup.sql

# Backup automático (cron)
0 2 * * * mysqldump -u root -pSENHA dashboard_erros > /backups/db_$(date +\%Y\%m\%d).sql
```

---

## 📊 Monitoramento

### PM2 Monitoramento
```bash
# Dashboard em tempo real
pm2 monit

# Logs
pm2 logs dashboard

# Reiniciar automático
pm2 restart dashboard --cron "0 0 * * *"
```

### Health Checks
```bash
# Verificar status da API
curl http://localhost:3001/api/health

# Monitorar com Uptime Robot
# 1. Acesse https://uptimerobot.com
# 2. Adicione seu endpoint
# 3. Configure alertas
```

---

## 🔧 Troubleshooting

### Erro: "Port already in use"
```bash
# Encontre o processo
lsof -i :3001

# Mate o processo
kill -9 <PID>
```

### Erro: "Cannot connect to database"
```bash
# Verifique MySQL
systemctl status mysql

# Reinicie MySQL
systemctl restart mysql

# Verifique credenciais em .env
```

### Erro: "Permission denied"
```bash
# Verifique permissões
ls -la /var/www/dashboard-server

# Corrija permissões
chown -R www-data:www-data /var/www/dashboard-server
chmod -R 755 /var/www/dashboard-server
```

---

## 📈 Performance

### Otimizações Recomendadas
1. **Caching**: Configure Redis para cache
2. **CDN**: Use CloudFlare para arquivos estáticos
3. **Compressão**: Gzip já está configurado
4. **Database**: Adicione mais índices conforme necessário

### Monitoramento de Performance
```bash
# CPU e Memória
top

# Disco
df -h

# Rede
netstat -an | grep ESTABLISHED | wc -l
```

---

## 🚀 CI/CD com GitHub Actions

Crie `.github/workflows/deploy.yml`:
```yaml
name: Deploy

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Deploy to server
        env:
          SSH_KEY: ${{ secrets.SSH_KEY }}
          HOST: ${{ secrets.HOST }}
          USER: ${{ secrets.USER }}
        run: |
          mkdir -p ~/.ssh
          echo "$SSH_KEY" > ~/.ssh/id_rsa
          chmod 600 ~/.ssh/id_rsa
          ssh-keyscan -H $HOST >> ~/.ssh/known_hosts
          ssh $USER@$HOST 'cd /var/www/dashboard-server && git pull && npm install && pm2 restart dashboard'
```

---

## 📞 Suporte

Para problemas:
1. Verifique os logs
2. Teste a API com `curl`
3. Verifique a conectividade do banco de dados
4. Consulte a documentação oficial das ferramentas usadas
