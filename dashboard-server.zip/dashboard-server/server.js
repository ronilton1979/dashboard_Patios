// ========================================
// DASHBOARD ERROS PÁTIOS - BACKEND API
// ========================================

const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Pool de conexões MySQL
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'dashboard_erros',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// ========================================
// ROTAS DA API
// ========================================

// 1. Obter todos os erros com filtros
app.get('/api/erros', async (req, res) => {
  try {
    const { data_inicio, data_fim, patio, colaborador, page = 1, limit = 50 } = req.query;
    let query = 'SELECT * FROM erros WHERE 1=1';
    const params = [];

    if (data_inicio) {
      query += ' AND data >= ?';
      params.push(data_inicio);
    }
    if (data_fim) {
      query += ' AND data <= ?';
      params.push(data_fim);
    }
    if (patio) {
      query += ' AND patios = ?';
      params.push(patio);
    }
    if (colaborador) {
      query += ' AND colaborador = ?';
      params.push(colaborador);
    }

    // Paginação
    const offset = (page - 1) * limit;
    query += ' ORDER BY data DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), offset);

    const connection = await pool.getConnection();
    const [rows] = await connection.query(query, params);
    connection.release();

    res.json({
      success: true,
      data: rows,
      page: parseInt(page),
      limit: parseInt(limit)
    });
  } catch (error) {
    console.error('Erro ao buscar erros:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// 2. Obter top 5 pátios
app.get('/api/top-patios', async (req, res) => {
  try {
    const { data_inicio, data_fim } = req.query;
    let query = 'SELECT patios, COUNT(*) as quantidade FROM erros WHERE 1=1';
    const params = [];

    if (data_inicio) {
      query += ' AND data >= ?';
      params.push(data_inicio);
    }
    if (data_fim) {
      query += ' AND data <= ?';
      params.push(data_fim);
    }

    query += ' GROUP BY patios ORDER BY quantidade DESC LIMIT 5';

    const connection = await pool.getConnection();
    const [rows] = await connection.query(query, params);
    connection.release();

    res.json({ success: true, data: rows });
  } catch (error) {
    console.error('Erro ao buscar top pátios:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// 3. Obter top 5 colaboradores
app.get('/api/top-colaboradores', async (req, res) => {
  try {
    const { data_inicio, data_fim, patio } = req.query;
    let query = 'SELECT colaborador, COUNT(*) as quantidade FROM erros WHERE 1=1';
    const params = [];

    if (data_inicio) {
      query += ' AND data >= ?';
      params.push(data_inicio);
    }
    if (data_fim) {
      query += ' AND data <= ?';
      params.push(data_fim);
    }
    if (patio) {
      query += ' AND patios = ?';
      params.push(patio);
    }

    query += ' GROUP BY colaborador ORDER BY quantidade DESC LIMIT 5';

    const connection = await pool.getConnection();
    const [rows] = await connection.query(query, params);
    connection.release();

    res.json({ success: true, data: rows });
  } catch (error) {
    console.error('Erro ao buscar top colaboradores:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// 4. Obter top 5 observações (erros)
app.get('/api/top-obs', async (req, res) => {
  try {
    const { data_inicio, data_fim, patio, colaborador } = req.query;
    let query = 'SELECT obs, COUNT(*) as quantidade FROM erros WHERE 1=1';
    const params = [];

    if (data_inicio) {
      query += ' AND data >= ?';
      params.push(data_inicio);
    }
    if (data_fim) {
      query += ' AND data <= ?';
      params.push(data_fim);
    }
    if (patio) {
      query += ' AND patios = ?';
      params.push(patio);
    }
    if (colaborador) {
      query += ' AND colaborador = ?';
      params.push(colaborador);
    }

    query += ' GROUP BY obs ORDER BY quantidade DESC LIMIT 5';

    const connection = await pool.getConnection();
    const [rows] = await connection.query(query, params);
    connection.release();

    res.json({ success: true, data: rows });
  } catch (error) {
    console.error('Erro ao buscar top obs:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// 5. Obter estatísticas gerais
app.get('/api/stats', async (req, res) => {
  try {
    const { data_inicio, data_fim } = req.query;
    let query = 'SELECT COUNT(*) as total_erros, COUNT(DISTINCT patios) as total_patios, COUNT(DISTINCT colaborador) as total_colaboradores FROM erros WHERE 1=1';
    const params = [];

    if (data_inicio) {
      query += ' AND data >= ?';
      params.push(data_inicio);
    }
    if (data_fim) {
      query += ' AND data <= ?';
      params.push(data_fim);
    }

    const connection = await pool.getConnection();
    const [rows] = await connection.query(query, params);
    connection.release();

    res.json({ success: true, data: rows[0] });
  } catch (error) {
    console.error('Erro ao buscar estatísticas:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// 6. Obter lista de pátios únicos
app.get('/api/patios', async (req, res) => {
  try {
    const connection = await pool.getConnection();
    const [rows] = await connection.query('SELECT DISTINCT patios FROM erros ORDER BY patios');
    connection.release();

    res.json({ success: true, data: rows.map(r => r.patios) });
  } catch (error) {
    console.error('Erro ao buscar pátios:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// 7. Obter lista de colaboradores únicos
app.get('/api/colaboradores', async (req, res) => {
  try {
    const connection = await pool.getConnection();
    const [rows] = await connection.query('SELECT DISTINCT colaborador FROM erros ORDER BY colaborador');
    connection.release();

    res.json({ success: true, data: rows.map(r => r.colaborador) });
  } catch (error) {
    console.error('Erro ao buscar colaboradores:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// 8. Obter intervalo de datas
app.get('/api/date-range', async (req, res) => {
  try {
    const connection = await pool.getConnection();
    const [rows] = await connection.query('SELECT MIN(data) as data_minima, MAX(data) as data_maxima FROM erros');
    connection.release();

    res.json({ success: true, data: rows[0] });
  } catch (error) {
    console.error('Erro ao buscar intervalo de datas:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Servir arquivo index.html para SPA
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
  console.log(`📊 Dashboard disponível em http://localhost:${PORT}`);
  console.log(`🔌 API disponível em http://localhost:${PORT}/api`);
});

module.exports = app;
